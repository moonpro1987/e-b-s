<template>
  <div class="card mb-3" style="max-width: 540px">
    <div class="row g-0">
      <div class="col-md-4">
        <img
          :src="imagen"
          class="img-fluid" 
          alt="..."
        />
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">{{ titulo_evento }}</h5>
          <p class="card-text">{{ descripcion }}</p>
          <br>
          <div class="button">
          <button @click="enviarEvento" v-if="!inscrito" class="btn btn-primary" 
            >Inscribir</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {  
    data(){
        return{
          inscrito:false
        }
    },
     methods:{
      async enviarEvento(){
        let miAlerta3 = this.$alert
        let datosEvento={
          idEvent: this.idEvent,
          idUser: localStorage.idUser
        }
        axios.post("https://ebsequipo1gurpo16.herokuapp.com/api/suscription/nuevo", datosEvento).then(res =>(miAlerta3("Se ha suscrito correctamente al evento"))).catch(err =>(console.log(err)))
        this.inscrito=true 
      }
    },
    props:{
        imagen: String,
        titulo_evento: String,
        descripcion: String,
        idEvent: String,
    }
};
</script>

<style>

</style>