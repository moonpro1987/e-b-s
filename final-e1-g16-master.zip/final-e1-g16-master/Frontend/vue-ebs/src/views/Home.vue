<template>
  <div class="home">
    <div class="container my-5">
        <div class="row">
          <div class="col-sm-12 col-lg-6" v-for="e in eventos" :key="e.id">
            <carta :imagen="e.urlImagen"
            :titulo_evento="e.nombre"
            :descripcion="e.descripcion"
            :idEvent="e._id"></carta>
            </div>
          </div>
        </div>
    </div>


  
</template>

<script>
import Carta from '../components/Carta.vue'
import router from "../router";
import axios from "axios";
export default {
  name: 'Home',
  data(){
    return {
      eventos:[]
    }
  },
  components: {
    Carta
  },
  beforeMount() {
    if(!localStorage.idUser || localStorage.idUser == 'undefined'){
      router.push('/login')
    }

  },
  mounted() {
    let config = {
      method: 'get',
      url: 'https://ebsequipo1gurpo16.herokuapp.com/api/user/'+localStorage.idUser,
      headers: { },
    };
    axios
      .get("https://ebsequipo1gurpo16.herokuapp.com/api/event/get/all")
      .then((res) => (this.eventos = res.data));

    axios(config)
        .then(function (response) {
          if (response.data !== null) {
            const dataUser = response.data;
            console.log('CARGA HOME:::::: ', dataUser)
          }
        })
  },
}
</script>
<style >


body {
  
  background-color: #99AAB0;
  
}


.card-body {
  background: #6AC4FB;
  width: 350px;
  height: 300px;
  font-family: roboto;
  font-size: 14px;
}


.card {
  background-color: #6AC4FB;
  width:auto !important;
  
}
.btn:hover {
  background: #797981;
  border-bottom: 1px solid;
  
}

.img-fluid{
  max-width: 100%;
  height: auto !important;
}


  





</style>