<template>
  <div class="container">
    <div id="contregistro" class="col-md-4 ms-md-12">
      <h3 style="text-align: center">Registro en EBM</h3>
      <hr size="6px" />
      <form class="form-horizontal">
        <div class="mb-3 row">
          <label for="inputName" class="col-md-4 col-form-label">Nombre</label>
          <div class="col-md-8">
            <input
              v-model="user.nombre"
              :val="user.nombre"
              type="text"
              v-on:keypress="isLetter($event)"
              
              class="form-control"
              id="inputName"
              placeholder="Espacio para texto"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputLastname" class="col-md-4 col-form-label"
            >Apellido</label
          >
          <div class="col-md-8">
            <input
              v-model="user.apellido"
              :val="user.apellido"
              type="text"
              v-on:keypress="isLetter($event)"
              class="form-control"
              id="inputLastname"
              placeholder="Espacio para texto"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputEmail" class="col-md-4 col-form-label">Email</label>
          <div class="col-md-8">
            <input
              v-model="user.email"
              :val="user.email"
              type="email"
              class="form-control"
              id="inputEmail"
              placeholder="Ejemplo@mail.com"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="Tipodoc" class="col-md-4"
            >Seleccione el tipo de documento</label
          >
          <div class="col-md-8">
            <select
              v-model="user.tipo_doc"
              id="Tipodoc"
              name="Tipo de documento"
              class="form-select"
            >
              <option selected value="">Seleccione una opcion</option>
              <option value="cedula">Cedula</option>
              <option value="pasaporte">Pasaporte</option>
              <option value="ce">Cedula de extranjeria</option>
            </select>
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputNumber" class="col-md-4 col-form-label"
            >Numero de documento</label
          >
          <div class="col-md-8">
            <input
              v-model="user.doc"
              :val="user.doc"
              type="text"
              v-on:keypress="isNumber($event)"
              class="form-control"
              id="inputNumber"
              placeholder="Ingrese su numero de documento"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputPassword" class="col-md-4 col-form-label"
            >Password</label
          >
          <div class="col-md-8">
            <input
              v-model="user.pass"
              :val="user.pass"
              type="password"
              class="form-control"
              id="inputPassword"
              placeholder="Minimo 6 caracteres"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputConPassword" class="col-md-4 col-form-label"
            >Confirmar Password</label
          >
          <div class="col-md-8">
            <input
              v-model="vpass.conpass"
              :val="user.conpass"
              type="password"
              class="form-control"
              id="inputConPassword"
              placeholder="Repita la contraseña anterior"
            />
          </div>
        </div>
        <div class="botones">
          <div class="mb-2 row">
            <div class="col-md-8 centrarbotones">
              <b-button
                @click="registrar(user)"
                to="/login" type="submit" class="btn">Registrarse</b-button
              >
              <router-link to="/login" class="btn">Cancelar</router-link>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import router from "../router";

export default {
  data() {
    return {
      user: {
        nombre: "",
        apellido: "",
        email: "",
        tipo_doc: "",
        doc: "",
        pass: "",
        activo: true,
      },
      vpass: {
        conpass: "",
      },
    };
  },
  methods: {
    isLetter(e) {
      let char = String.fromCharCode(e.keyCode); // Get the character
      if (/^[A-Za-z\s]+$/.test(char)) return true;
      // Match with regex
      else e.preventDefault(); // If not match, don't add to input text
      
    },
    isNumber(e) {
      let char = String.fromCharCode(e.keyCode); // Get the character
      if (/^[\d]+$/.test(char)) return true;
      // Match with regex
      else e.preventDefault(); // If not match, don't add to input text
      
    },
    
    registrar(user) {
      if (user.pass !== this.vpass.conpass) {
        alert("No coincide la contraseña ");
        // const dataUser = response.data;
        console.log("pass:::::: ", user.pass);
        console.log("passCON:::::: ", this.vpass.conpass);
        return;
      } else if (user.nombre == null || user.nombre == "") {
        alert("Es necesario que digite su nombre");
        return;
      } else if (user.apellido == null || user.apellido == "") {
        alert("Es necesario que digite su apellido");
        return;
      } else if (user.email == null || user.email == "") {
        alert("Es necesario que digite su Email");
        return;
      } else if (user.tipo_doc == "") {
        alert("Es necesario que seleccione un tipo de documento");
        return;
      } else if (user.doc == null || user.doc == "") {
        alert("Es necesario que digite su numero de documento");
        return;
      }
      let configverify = {
        method: "get",
        url:
          "https://ebsequipo1gurpo16.herokuapp.com/api/user/email/" +
          user.email,
        headers: {},
      };

      axios(configverify).then(function (response) {
        console.log(response);

        if (response.data !== null) {
          alert("El correo ya existe " + user.email);
        } else {
          let config = {
            method: "post",
            url: "https://ebsequipo1gurpo16.herokuapp.com/api/user/nuevo",
            headers: { "Content-Type": "application/json" },
            data: user,
          };

          axios(config)
            .then(function (response) {
              console.log(response);
              localStorage.idUser = response.data._id;
              //this.logeado= true;
              router.push("/");
            })
            .catch(function (error) {
              alert("Ocurrio un error, por favor intente más tarde");
            });
        }
      });
    },
  },
};
</script>

<style scoped>
hr {
  background-color: white;
}

#contregistro {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 20px;
  background-color: #2babd7;
  border-radius: 20px;
  box-shadow: 7px 13px 37px #000;
  padding: 50px;
  margin: 10px;
  width: 100%;
}
.centrarbotones {
  display: flex;
  justify-content: center;
}
.btn {
  width: 40%;
  margin: 0 5%;
  text-align: center;
  border: auto;
  color: white;
  margin-bottom: 16px;
  font-style: Roboto;
  background-color: #7e7f8d;
  text-align: center;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}

.botones {
  margin-left: 30%;
}

#contregistro #contpadre {
  position: relative;
}

#reg {
  position: relative;
}
</style>