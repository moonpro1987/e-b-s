<template>
  <section id="form-login" class="form-login">
    <h5>Registro en EBM</h5>
    <input
      v-model="user.email"
      class="controls"
      type="text"
      name="Email"
      :val="user.email"
      placeholder="Email"
    />
    <input
        v-model="user.pass"
      class="controls"
      type="password"
      name="Contrasena"
      :val="user.pass"
      placeholder="Contraseña"
    />
    <div class="centrarbotones">
      <button @click="login(user)" class="buttons">Ingresar</button>
       <button @click="registro()" class="buttons">Registrarse</button>
    </div>
    <hr />
    <a>¿Olvidaste la contraseña?</a>
  </section>
</template>

<script>
import axios from "axios";
import router from "../router";
import VueSimpleAlert from "vue-simple-alert";


export default {
    data() {
       return{
         user:{
           email:'',
           pass:''
         }
       }
   }
      ,
   methods:{
    validEmail: function (email) {
      var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
         return re.test(email);
    },
    registro(){
      if(localStorage.idUser){
        this.$alert("Imposible registrarse ya se encuentra logueado en el sistema...")
      } else {
                router.push('/registro')

      }

    },
   cerrar(){
      this.logeado= false;
      localStorage.idUser =null;
    },
    login(user){
     let miAlerta= this.$alert;
     let config = {
        method: 'get',
        url: 'https://ebsequipo1gurpo16.herokuapp.com/api/user/email/'+user.email,
        headers: { }
      }

      if(localStorage.idUser){
        this.$alert("Ya se encuentra logueado en el sistema...")
      } else {
      //  alert("Debe ingresar el usuario y la contraseña.")
        if (!this.validEmail(user.email)){
          this.$alert("Debe ingresar un usuario o email válido.")
           //console.log("Debe ingresar un usuario válido.")
        } else {


      axios(config)
          .then(function (response) {
            if(response.data !== null){
              const dataUser = response.data;
              //console.log('passAPI:::::: ',dataUser.pass)
              //console.log('passFORM:::::: ',user.pass)
              //console.log("Usuario :"+dataUser);


              if(dataUser.pass === user.pass){
                if (dataUser.activo){
                  // almacenar variable en localstora del ID del usuario para que las otras vistas comprueben antes de cargarse si existe esta
                  // variable y permitan su visualizacion.
                  localStorage.idUser = dataUser._id
                  //this.logeado= true;
                  miAlerta("Usuario logueado.");
                  router.push('/')
                } else{miAlerta("Usuario Inactivo.")}
              }else{
                  miAlerta("Usuario o contraseña no validos.");
                  //alert("Usuario o contraseña no validos")
              }
            } else {
              miAlerta("Usuario no registrado.");
              //alert("Usuario no registrado")
            }

          })
          .catch(function (error) {
            miAlerta("Ocurrio un error, por favor intente más tarde "+error)
          });

      this.logeado = true
      }
    }
  }
  }
};
</script>

<style scoped>
.centrarbotones {
  display: flex;
  justify-content: center;
}
.form-login {
  width: 400px;
  height: 340px;
  background: #01A7C2;
  margin: auto !important;
  margin-top: 180px;
  /*box-shadow: 7px 13px 37px #000;*/
  padding: 20px 30px;
  border-top: 4px solid #b7adcf;
  color: white;  
  border-radius: 20px;
}
.form-login h5 {
  margin: 0;
  text-align: center;
  height: 40px;
  margin-bottom: 30px;
  border-bottom: 1px solid;
  font-size: 20px;
}
.controls {
  width: 100%;
  border-top: 1px solid #b7adcf;
  margin-bottom: 15px;
  padding: 11px 10px;
  background: silver;
  font-size: 14px;
  font-weight: bold;
}
.buttons {
  width: 40%;
  margin: 0 5%;
  text-align: center;
  background: rgb(79, 83, 95);
  border: auto;
  color: white;
  margin-bottom: 16px; 
  border-radius: 7px;
}
.form-login p {
  height: 40px;
  text-align: center;
  border-bottom: 1px solid;
}
.form-login a {
  color: white;
  text-decoration: none;
  font-size: 14px;
}
.form-login a:hover {
  text-decoration: underline;
}
</style>