<template>
  <div class="container">
    <div id="containerPerfil" class="col-md-4 ms-md-12">
      <h3>Perfil</h3>
      <hr size="6px" />
      <div class="form-horizontal">
        <div class="mb-3 row">
          <label for="inputName3" class="col-md-4 col-form-label"
            >Nombres</label
          >
          <div class="col-md-8">
            <input
              v-model="user.nombre"
              :val="user.nombre"
              type="text"
              class="form-control"
              id="inputName3"
              placeholder="Nombres"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputLastname3" class="col-md-4 col-form-label"
            >Apellidos</label
          >
          <div class="col-md-8">
            <input
              v-model="user.apellido"
              :val="user.apellido"
              type="text"
              class="form-control"
              id="inputLastname3"
              placeholder="Apellidos"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="Tipodoc" class="col-md-4"
            >Seleccione el tipo de documento</label
          >
          <div class="col-md-8">
            <select id="Tipodoc" name="Tipo de documento" class="form-select">
              <option selected value="">Seleccione una opcion</option>
              <option value="cedula">Cedula</option>
              <option value="pasaporte">Pasaporte</option>
              <option value="ce">Cedula de extranjeria</option>
            </select>
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputNumber3" class="col-md-4 col-form-label"
            >Numero de documento</label
          >
          <div class="col-md-8">
            <input
              v-model="user.doc"
              :val="user.doc"
              type="text"
              class="form-control"
              id="inputNumber3"
              placeholder="Ingrese su numero de documento"
            />
          </div>
        </div>
        <div class="mb-3 row">
          <label for="inputPassword3" class="col-md-4 col-form-label"
            >Password</label
          >
          <div class="col-md-8">
            <input
              v-model="user.pass"
              :val="user.pass"
              type="password"
              class="form-control"
              id="inputPassword3"
              placeholder="Password"
            />
          </div>
        </div>
        <div class="buttons">
          <div class="mb-2 row">
            <div class="col-md-8">
              <button
                v-on:click="actualizarUsuario(user)"
                class="btn btn-danger btn-block"
              >
                Guardar
              </button>
              <button @click="eliminarCuenta()" class="btn btn-danger btn-block">Eliminar Cuenta</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import router from "../router";

export default {
  data() {
    return {
      user: {
        nombre: "",
        apellido: "",
        email: "",
        tipo_doc: "",
        doc: "",
        pass: "",
        activo:false
      },
    };
  },

  beforeMount() {
    const id = localStorage.getItem("idUser");
    if (!id || id == "undefined") {
      router.push("/login");
    } else {
      console.log("obtuve el localstorage", id);
    }
  },

  mounted() {
    const config = {
      method: "get",
      url:
        "https://ebsequipo1gurpo16.herokuapp.com/api/user/" +
        localStorage.idUser,
      headers: {
        "Content-Type": "application/json",
      },
    };

    axios(config).then((response) => (this.user = response.data));

    //Conexion API para realizar actualizacion de datos
    /* var config2 = {
      method: "put",
      url: "https://ebsequipo1gurpo16.herokuapp.com/api/user/"+
        localStorage.idUser,
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };

    axios(config2)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      }); */
  },
  methods: {
    actualizarUsuario: function(user) {
      let miAlerta2= this.$alert;
      console.log('entre a metodo de cambio')
      console.log(user)
      const config1 = {
        method: "PUT",
        url:
          "https://ebsequipo1gurpo16.herokuapp.com/api/user/" +
          localStorage.idUser,
        headers: {
          "Content-Type": "application/json",
        },
        data: user,
      };

      axios(config1)
        .then(function (response) {
          console.log(JSON.stringify(response.data));
          miAlerta2('Se ha actualizado el usuario exitosamente')
        })
        .catch(function (error) {
          console.log(error);
        });
    },

    eliminarCuenta: function(user){
      if (alert("seguro quieres eliminar cuenta") == true){
        user.activo == false;
        this.actualizarUsuario(user);
      }
    },
    changeActivo: function(user){
      console.log(user)
      if(user.activo){
        this.user.activo = false;
      }else{
        this.user.activo = true;
      }
    },
  },

};
</script>

<style scoped>
#containerPerfil {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 20px;
  background-color: #2babd7;
  border-radius: 20px;
  box-shadow: 7px 13px 37px #000;
  padding: 50px;
  margin: 10px;
  width: 100%;
}

hr {
  background-color: white;
}

.btn {
  background-color: #7e7f8d;
  text-align: center;
  margin: 5%;
  height: 50%;
  width: 32%;
  font-family: Arial, Helvetica, sans-serif;
}

#containerPerfil {
  position: relative;
}

.buttons {
  margin-left: 30%;
}
</style>