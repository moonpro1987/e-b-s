<template>
  <div id="app">
    <div>
      <header>
        <div class="aswrapper">
          <nav class="navbar navbar-expand-lg navbar-light bg-info">
            <div class="container-fluid">
              <router-link to="/" class="navbar-brand" href="#">EBS</router-link>
              <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                  <router-link to="/" class="nav-link active" aria-current="page" href="#"
                    >Home</router-link
                  >
                  <router-link to="/perfil" class="nav-link" href="#">Perfil</router-link>
                  <router-link to="/login" v-if="!logeado" class="nav-link" href="#">Login</router-link>
                  <router-link to="/" v-if="logeado" class="nav-link" href="#">Cerrar Sesión</router-link>
                  <a to="" @click="cerrarSesion()" class="nav-link" href="#">Cerrar Sesión</a>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>
    </div>
    <router-view />
  </div>
</template>
<script>

import router from "./router";

export default {
    data:()=>({
      logeado:false
    }),
  methods: {
    cerrarSesion() {
      this.logeado = false;
      localStorage.removeItem('idUser');
      router.push('/login')
    },
  },
}
</script>

<style>
*{margin:0;padding:0};



</style>
