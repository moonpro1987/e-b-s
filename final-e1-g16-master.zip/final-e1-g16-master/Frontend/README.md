# equipo1-grupo16-equipo3-EBS

Este es el proyecto del equipo 1 grupo 16 llamado EBS (Eventos Bienestar Social)

## Getting started
para iniciar ejecute por favor los siguientes comandos:

```
git clone https://gitlab.com/jadamavecool/equipo1-grupo16-equipo3-ebs
```
```
git pull origin main
```

```
git fetch
```

```
git checkout {nombre de su rama}
```

##IMPORTANTE

Recuerde que antes de hacer commit SIEMPRE debe hacer PULL para evitar sobreescribir codigo funcional del repositorio remoto
